#En esta parte se analizaran los sostos de la comida
Carneroja = 700
Camarones = 400
Carneblanca = 250
Pescado = 350

#sacamos la cantidad de dinero que va a gasatr 
Cr= int(input("introduzca el número de días que planea cocinar carne roja al mes"))
C= int(input("introduca el número de días que planea cocinar camarones al mes"))
Cb= int(input("intoduzca el número de días que planea cocinar carne blanca al mes"))
P= int(input("introduzca el número de días que planea cocianr pescado al mes"))

res= ((Carneroja*Cr)+(Camarones*C)+(Carneblanca*Cb)+(Pescado*P))
print("El dinero que vas a gastar al mes de tus comidas es")
print(res)

dineroporsemana= (res/4)
print("El dinero que vas a gastar por semana de tus comidas es")
print(dineroporsemana)

#preguntamos el dinero que tiene para gastar 
Dinero= int(input("introduzca la cantidad de dinero a gastar"))
proceso=  (Dinero-res)
print("tu saldo es")
print(proceso)

